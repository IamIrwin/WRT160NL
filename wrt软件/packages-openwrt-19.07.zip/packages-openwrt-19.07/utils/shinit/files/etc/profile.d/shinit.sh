export ENV=/etc/shinit
